<div class="container mt">
    <img width= "200" class = "rounded-circle shadow" src="<?php echo BASEURL; ?>/img/Yuito.jpg" alt="Shinichi">
    <h1 class="mt-4">About Me</h1>
    <p>Hallo, nama saya <?= $data['nama']; ?>, umur saya <?= $data['umur']?> tahun, saya adalah seorang <?= $data['pekerjaan'] ?>.</p>
</div>