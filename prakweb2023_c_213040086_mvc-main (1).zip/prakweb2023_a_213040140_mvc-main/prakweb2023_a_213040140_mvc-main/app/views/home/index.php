<div class="container">
  <div class="jumbotron mt-4">
    <h1 class="display-4">Selamat Datang di Website Saya Cuy!</h1>
    <p class="lead">Hello, nama saya <?php echo $data['nama']; ?></p>
    <hr class="my-4">
    <p>Di sini hanya untuk bahan pembelajaran.</p>
    <a class="btn btn-primary btn-lg" href="" role="button">Detail</a>
  </div>
</div>