<?php

class User_model
{
    private $nama = 'Adam Maulana K';

    public function getUser()
    {
        return $this->nama;
    }
}
